---
name: Prestige Terminal
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#ffb4aa'
  on-secondary: '#690003'
  secondary-container: '#c5020b'
  on-secondary-container: '#ffd2cc'
  tertiary: '#5ce976'
  on-tertiary: '#003911'
  tertiary-container: '#3bcc5d'
  on-tertiary-container: '#00511b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930005'
  tertiary-fixed: '#72fe88'
  tertiary-fixed-dim: '#53e16f'
  on-tertiary-fixed: '#002107'
  on-tertiary-fixed-variant: '#00531c'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0em
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '500'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  data-mono:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-sm: 16px
  margin-md: 32px
  margin-lg: 64px
---

## Brand & Style

The design system is engineered for a high-fashion, editorial-grade financial experience. It targets a sophisticated audience that values precision, scarcity, and heritage. The aesthetic evokes the atmosphere of a private members' club or a premium auction house—quiet, authoritative, and expensive.

The style is **Editorial Minimalism**. It leverages heavy use of pitch-black whitespace, strict alignment to a rigid grid, and high-contrast typography. Sharp corners and zero-radius borders are used exclusively to maintain a feeling of structural integrity and modern architectural discipline. The visual response should be one of "composed luxury," where the information is dense but never cluttered.

## Colors

The palette is rooted in a deep, absolute black (#0D0D0D) to provide a canvas where data and imagery can recede and emerge with clarity. 

- **Primary (Metallic Gold):** Used sparingly for "Legendary" status indicators, key highlights, and primary branding elements. It represents value and exclusivity.
- **Secondary & Tertiary (Semantic Trend):** Vibrant Red (#FF3B30) and Emerald Green (#34C759) are used strictly for performance data—price drops and gains. They are high-chroma to ensure instant legibility against the dark background.
- **Neutrals:** A tiered system of dark grays creates depth without breaking the monochromatic discipline. Borders are kept subtle to maintain the "seamless" appearance of the terminal.

## Typography

This design system employs a "Double-Axe" typographic strategy: a high-contrast serif for narrative/status and a clean sans-serif for functional data.

- **Headline (Bodoni Moda):** Used for titles, names of assets, and "Legendary" headers. The high stroke contrast brings a fashion-editorial feel.
- **Body & Data (Manrope):** A refined, balanced sans-serif used for all quantitative information, descriptions, and labels. 
- **Formatting:** Use all-caps with generous letter-spacing for category labels (e.g., "HORS D'AGE") to create a rhythmic, structured feel. Large numbers (prices) should be bold and clear, prioritizing scanability.

## Layout & Spacing

The layout follows a **Fixed 12-Column Grid** for desktop, ensuring that content remains centered and prestigious on ultra-wide displays. 

- **Grid Logic:** Use 24px gutters. Elements should span blocks of 3, 4, or 6 columns. 
- **Rhythm:** Spacing follows a strict 8px base unit. 
- **Negative Space:** Use generous vertical margins (64px+) between major sections to allow the brand to "breathe." Content density should be high within cards (terminal-style), but the gaps between cards should be substantial to imply a premium, unhurried experience.
- **Mobile:** On mobile devices, margins shrink to 16px, and grids collapse to a single column while maintaining the 8px vertical rhythm.

## Elevation & Depth

In this design system, depth is communicated through **Tonal Layering** and **Bold Outlines** rather than traditional shadows.

1.  **Level 0 (Base):** #0D0D0D. The foundation of all views.
2.  **Level 1 (Cards/Containers):** #1A1A1A. Used for asset cards and input areas. These are separated by thin, 1px borders (#2C2C2C).
3.  **Level 2 (Overlays/Modals):** #242424. Slightly lighter surfaces for elements that appear over the main UI.
4.  **Accents:** A subtle inner glow or a gold top-border (1px) can be used on "Legendary" tier cards to lift them from the grid visually without adding shadow bulk.

## Shapes

The shape language is strictly **Rectilinear**. All buttons, cards, tags, and input fields must have a border-radius of 0. This reinforces the "Terminal" and "Professional" aspect of the system, rejecting the softness of consumer-grade apps in favor of a precision-tool aesthetic. 

Dividers should be 1px thick and use the border color (#2C2C2C) to create subtle, geometric zones.

## Components

- **Buttons:** Primary buttons are solid gold (#D4AF37) with black text, strictly rectangular. Secondary buttons are ghost-style with 1px white or gold borders.
- **Asset Cards:** Cards use the #1A1A1A surface. Images should be high-contrast and slightly desaturated. Trend indicators (arrows/percentages) are placed in the top right corner of the image area or data row.
- **Data Tags:** Small, rectangular labels (e.g., "TOP 1") with a gold background and black text. These act as badges of honor within the system.
- **Inputs:** Search bars and dropdowns are styled with a 1px border and zero roundedness. The focus state uses a primary gold border.
- **Trend Indicators:** Use a combination of color and iconography (up/down triangles) to ensure accessibility. Trend colors apply to both text and small background "pills" for high-impact visibility.
- **Lists:** Data lists should use a mono-spaced numeric alignment for prices and quantities to ensure columns of numbers remain perfectly vertical.